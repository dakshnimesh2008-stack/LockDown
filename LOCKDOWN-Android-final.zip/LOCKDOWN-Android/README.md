# LOCKDOWN — Focus Today. Better Tomorrow.

Native Android (Kotlin + Jetpack Compose + Room + DataStore). Offline-first: no login, ads, analytics or INTERNET permission.
**Status: feature-complete source, debug build. NOT yet compiled or device-tested by the author** — the first GitHub Actions run is the first real compile.

## Features
- Home dashboard (reference design): focus ring computed from persisted timestamps, real stats, quick tiles, upcoming schedules, allowed-app row.
- Unlimited alarm-style schedules: name, start/end, one-time / daily / custom weekdays, enable, edit, duplicate, delete, notification toggle, optional per-schedule app subset. Overnight schedules supported. Overlap warning before saving.
- Scheduler: one calculated AlarmManager alarm for the next event (exact if permitted, otherwise inexact fallback). Recovery on boot, app update, clock change, time-zone change. Sessions are created once per window (no duplicates).
- Allowed apps: real installed-app list (launcher intent only, no QUERY_ALL_PACKAGES), search, select, reorder, remove, persisted.
- Launcher: LOCKDOWN can be the default Home app. During focus the home screen shows only allowed apps; Home presses show a focus message; emergency dialer always shown; End focus always available.
- Overlap policy: all active sessions apply; allowed apps = intersection of every active schedule's set; empty intersection shows a warning with recovery (edit apps / end focus).
- Statistics: completed, interrupted, total/today/7-day focus, current & best streak, 7-day chart, clear data.
- Guided setup, permission status (never assumed), Settings, Dark AMOLED + Bright themes (persisted, no flash).

## Build
No Gradle wrapper JAR is committed (it cannot be generated offline). The workflow installs Gradle 8.9 via
`gradle/actions/setup-gradle` and runs `gradle assembleDebug`. Push to `main` or run it manually
(Actions → Build LOCKDOWN debug APK) and download the `LOCKDOWN-debug-apk` artifact. Debug APK, not a signed release.
Unit tests: `gradle testDebugUnitTest` (schedule windows, overnight, overlap, whitelist intersection, stats/streaks).

## Not testable on an emulator / not verified
Reboot recovery, Doze/OEM battery-killer behaviour, exact-alarm permission flows, default-Home selection and
manufacturer launcher quirks must be checked on a real phone. UI/instrumented tests are not included.

## Honest limitations
A custom launcher cannot block Recents, the notification shade, system Settings or other launchers.
Strict enforcement would need a separate, documented Device Owner mode (not implemented, never silently provisioned).
Sessions that ended while the phone was off are recorded as completed at their planned end. Database upgrades from the
Stage-1 debug build reset local data (destructive migration).

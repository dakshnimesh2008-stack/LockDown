package com.daksh.lockdown.logic

import com.daksh.lockdown.data.ScheduleEntity
import com.daksh.lockdown.data.SessionEntity

data class FocusState(
    val active: List<SessionEntity> = emptyList(),
    val primary: SessionEntity? = null,
    val endMs: Long = 0L,
    val title: String = "",
    /** Allowed apps (package names, user order) that every active session permits. */
    val effectiveApps: List<String> = emptyList(),
    /** Focus is on but the effective set is empty. */
    val conflict: Boolean = false,
    /** The reason for the conflict is that no apps were chosen at all. */
    val noAppsChosen: Boolean = false
) {
    val isActive get() = active.isNotEmpty()
}

object FocusLogic {
    /**
     * Overlap policy: all active sessions apply at once and the effective app set is the INTERSECTION
     * of every active schedule's set (a schedule without a custom subset allows the whole list).
     * Nothing is silently disabled and the set is never silently widened.
     */
    fun compute(
        sessions: List<SessionEntity>,
        schedules: List<ScheduleEntity>,
        allowed: List<String>,
        now: Long
    ): FocusState {
        val active = sessions.filter { it.outcome == "ACTIVE" && now < it.plannedEndMs }
        if (active.isEmpty()) return FocusState()
        val byId = schedules.associateBy { it.id }
        var set: Set<String> = allowed.toSet()
        for (a in active) {
            val sub = a.scheduleId?.let { byId[it] }?.allowedPackages
                ?.split(",")?.filter { it.isNotBlank() }
            if (!sub.isNullOrEmpty()) set = set intersect sub.toSet()
        }
        val effective = allowed.filter { it in set }
        val primary = active.maxByOrNull { it.plannedEndMs }!!
        val title = primary.name + if (active.size > 1) " +${active.size - 1}" else ""
        return FocusState(
            active = active,
            primary = primary,
            endMs = primary.plannedEndMs,
            title = title,
            effectiveApps = effective,
            conflict = effective.isEmpty(),
            noAppsChosen = allowed.isEmpty()
        )
    }
}

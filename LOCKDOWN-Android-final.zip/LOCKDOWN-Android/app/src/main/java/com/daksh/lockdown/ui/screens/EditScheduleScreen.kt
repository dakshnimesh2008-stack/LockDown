@file:OptIn(ExperimentalMaterial3Api::class)

package com.daksh.lockdown.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daksh.lockdown.MainViewModel
import com.daksh.lockdown.data.ScheduleEntity
import com.daksh.lockdown.logic.ScheduleLogic
import com.daksh.lockdown.ui.components.*
import com.daksh.lockdown.ui.theme.LocalLockdownColors

private val DAY_SHORT = listOf("M", "T", "W", "T", "F", "S", "S")

@Composable
fun EditScheduleScreen(vm: MainViewModel, id: Long, onClose: () -> Unit) {
    val c = LocalLockdownColors.current
    val schedules by vm.schedules.collectAsState()
    val allowed by vm.allowed.collectAsState()
    val existing = remember(id, schedules.isEmpty()) { schedules.firstOrNull { it.id == id } }
    val key = existing?.id ?: 0L

    var name by remember(key) { mutableStateOf(existing?.name ?: "") }
    var startMin by remember(key) { mutableIntStateOf(existing?.startMinute ?: (9 * 60)) }
    var endMin by remember(key) { mutableIntStateOf(existing?.endMinute ?: (12 * 60)) }
    var mode by remember(key) {
        mutableIntStateOf(
            when {
                existing == null -> 1
                existing.daysMask == 0 -> 0
                existing.daysMask == 127 -> 1
                else -> 2
            }
        )
    }
    var customMask by remember(key) { mutableIntStateOf(if (existing != null && existing.daysMask != 0) existing.daysMask else 0b0011111) }
    var icon by remember(key) { mutableStateOf(existing?.icon ?: "book") }
    var notify by remember(key) { mutableStateOf(existing?.notify ?: true) }
    var subset by remember(key) {
        mutableStateOf(existing?.allowedPackages?.split(",")?.filter { it.isNotBlank() }?.toSet() ?: emptySet<String>())
    }
    var useSubset by remember(key) { mutableStateOf(existing?.allowedPackages != null) }
    var error by remember { mutableStateOf<String?>(null) }
    var pickStart by remember { mutableStateOf(false) }
    var pickEnd by remember { mutableStateOf(false) }

    val mask = when (mode) { 0 -> 0; 1 -> 127; else -> customMask }
    val candidate = ScheduleEntity(
        id = id, name = name, startMinute = startMin, endMinute = endMin, daysMask = mask
    )
    val conflicts = remember(schedules, startMin, endMin, mask) {
        schedules.filter { it.enabled && it.id != id && ScheduleLogic.overlaps(candidate, it) }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        ScreenTitle(if (id == 0L) "Add Schedule" else "Edit Schedule", onBack = onClose)

        OutlinedTextField(
            value = name, onValueChange = { name = it.take(40) },
            label = { Text("Schedule name") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = c.accent, unfocusedBorderColor = c.border)
        )

        SectionCard {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TimeBox("Start", startMin, Modifier.weight(1f)) { pickStart = true }
                TimeBox("End", endMin, Modifier.weight(1f)) { pickEnd = true }
            }
            if (startMin == endMin) {
                Spacer(Modifier.height(8.dp))
                Text("Start and end must be different.", color = Color(0xFFFF6B6B), fontSize = 12.sp)
            } else if (endMin < startMin) {
                Spacer(Modifier.height(8.dp))
                Text("Ends the next day (crosses midnight).", color = c.textSecondary, fontSize = 12.sp)
            }
        }

        SectionCard {
            Text("Repeat", color = c.text, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("One time", "Daily", "Custom").forEachIndexed { i, label ->
                    FilterChip(selected = mode == i, onClick = { mode = i }, label = { Text(label) })
                }
            }
            if (mode == 2) {
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    DAY_SHORT.forEachIndexed { i, d ->
                        val on = ((customMask shr i) and 1) == 1
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(50))
                                .then(if (on) Modifier.background(c.accent) else Modifier.border(1.dp, c.border, RoundedCornerShape(50)))
                                .clickable { customMask = customMask xor (1 shl i) },
                            contentAlignment = Alignment.Center
                        ) { Text(d, color = if (on) c.onAccent else c.textSecondary, fontSize = 14.sp) }
                    }
                }
            }
        }

        SectionCard {
            Text("Icon", color = c.text, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ICON_KEYS.forEach { k ->
                    val sel = icon == k
                    Box(
                        Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (sel) c.accent else c.tile)
                            .clickable { icon = k },
                        contentAlignment = Alignment.Center
                    ) { Icon(iconFor(k), contentDescription = k, tint = if (sel) c.onAccent else c.text) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Notify when focus starts and ends", color = c.text, modifier = Modifier.weight(1f), fontSize = 14.sp)
                Switch(checked = notify, onCheckedChange = { notify = it })
            }
        }

        SectionCard {
            Text("Apps during this schedule", color = c.text, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !useSubset, onClick = { useSubset = false }, label = { Text("All allowed apps") })
                FilterChip(selected = useSubset, onClick = { useSubset = true }, label = { Text("Only some") })
            }
            if (useSubset) {
                Spacer(Modifier.height(8.dp))
                if (allowed.isEmpty()) {
                    Text("Choose your allowed apps first (Apps tab).", color = c.textSecondary, fontSize = 13.sp)
                } else {
                    allowed.forEach { a ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                subset = if (a.packageName in subset) subset - a.packageName else subset + a.packageName
                            },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(checked = a.packageName in subset, onCheckedChange = {
                                subset = if (it) subset + a.packageName else subset - a.packageName
                            })
                            AppIcon(a.packageName, 32.dp)
                            Spacer(Modifier.width(10.dp))
                            AppLabelText(a.packageName)
                        }
                    }
                }
            }
        }

        if (conflicts.isNotEmpty()) {
            WarningCard(
                "Overlaps with: " + conflicts.joinToString { it.name } +
                    ". Overlapping schedules run together and only apps allowed by every one of them stay available. " +
                    "Nothing is disabled automatically."
            )
        }
        error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp) }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            SecondaryButton("Cancel", Modifier.weight(1f), onClose)
            PrimaryButton("Save", Modifier.weight(1f)) {
                when {
                    startMin == endMin -> error = "Start and end time must be different."
                    mode == 2 && customMask == 0 -> error = "Pick at least one day."
                    useSubset && subset.isEmpty() -> error = "Select at least one app, or choose \"All allowed apps\"."
                    else -> {
                        vm.saveSchedule(
                            ScheduleEntity(
                                id = existing?.id ?: 0L,
                                name = name.trim().ifEmpty { "Focus" },
                                startMinute = startMin, endMinute = endMin, daysMask = mask,
                                enabled = existing?.enabled ?: true, icon = icon, notify = notify,
                                allowedPackages = if (useSubset) subset.joinToString(",") else null
                            )
                        )
                        onClose()
                    }
                }
            }
        }
    }

    if (pickStart) TimeDialog(startMin, { pickStart = false }) { startMin = it; pickStart = false }
    if (pickEnd) TimeDialog(endMin, { pickEnd = false }) { endMin = it; pickEnd = false }
}

@Composable
private fun TimeBox(label: String, minute: Int, modifier: Modifier, onClick: () -> Unit) {
    val c = LocalLockdownColors.current
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(c.tile)
            .clickable(onClick = onClick)
            .padding(14.dp)
    ) {
        Text(label, color = c.textSecondary, fontSize = 12.sp)
        Text(ScheduleLogic.timeLabel(minute), color = c.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun TimeDialog(initial: Int, onDismiss: () -> Unit, onConfirm: (Int) -> Unit) {
    val c = LocalLockdownColors.current
    val st = rememberTimePickerState(initial / 60, initial % 60, false)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        text = { TimePicker(state = st) },
        confirmButton = { TextButton(onClick = { onConfirm(st.hour * 60 + st.minute) }) { Text("OK", color = c.accentSoft) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.textSecondary) } }
    )
}

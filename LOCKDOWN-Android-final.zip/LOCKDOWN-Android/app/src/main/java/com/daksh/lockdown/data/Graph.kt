package com.daksh.lockdown.data

import android.app.Application
import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Room

val Context.dataStore by preferencesDataStore(name = "lockdown_prefs")

object Prefs {
    val DARK_THEME = booleanPreferencesKey("dark_theme")
    val SETUP_DONE = booleanPreferencesKey("setup_done")
}

object Graph {
    private lateinit var app: Application

    fun init(application: Application) {
        app = application
    }

    val db: AppDatabase by lazy {
        Room.databaseBuilder(app, AppDatabase::class.java, "lockdown.db")
            .fallbackToDestructiveMigration() // Stage-1 debug builds only; v1 data is discarded.
            .build()
    }
}

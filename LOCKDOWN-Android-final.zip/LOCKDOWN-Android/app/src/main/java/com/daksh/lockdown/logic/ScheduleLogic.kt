package com.daksh.lockdown.logic

import com.daksh.lockdown.data.ScheduleEntity
import com.daksh.lockdown.data.SessionEntity
import java.time.Instant
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale

object ScheduleLogic {
    private val DAY_NAMES = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

    fun matches(mask: Int, date: LocalDate): Boolean =
        mask == 0 || ((mask shr (date.dayOfWeek.value - 1)) and 1) == 1

    /** Next time this schedule will start strictly after [now], or null if none within 8 days. */
    fun nextStart(s: ScheduleEntity, now: ZonedDateTime): ZonedDateTime? {
        val start = LocalTime.of(s.startMinute / 60, s.startMinute % 60)
        for (offset in 0..7) {
            val date = now.toLocalDate().plusDays(offset.toLong())
            if (matches(s.daysMask, date)) {
                val candidate = date.atTime(start).atZone(now.zone)
                if (candidate.isAfter(now)) return candidate
            }
        }
        return null
    }

    /**
     * The (startMs, endMs) window of this schedule that contains [now], or null.
     * Checks yesterday's start too, so windows that cross midnight are found after midnight.
     */
    fun activeWindow(s: ScheduleEntity, now: ZonedDateTime): Pair<Long, Long>? {
        for (back in 1 downTo 0) {
            val date = now.toLocalDate().minusDays(back.toLong())
            if (!matches(s.daysMask, date)) continue
            val start = date.atTime(s.startMinute / 60, s.startMinute % 60).atZone(now.zone)
            var end = date.atTime(s.endMinute / 60, s.endMinute % 60).atZone(now.zone)
            if (!end.isAfter(start)) end = end.plusDays(1)
            if (!now.isBefore(start) && now.isBefore(end)) {
                return start.toInstant().toEpochMilli() to end.toInstant().toEpochMilli()
            }
        }
        return null
    }

    fun crossesMidnight(s: ScheduleEntity) = s.endMinute <= s.startMinute

    fun durationMinutes(s: ScheduleEntity): Int {
        val d = (s.endMinute - s.startMinute + 1440) % 1440
        return if (d == 0) 1440 else d
    }

    /** True if the two schedules can be active at the same time (weekly timeline, wraps around). */
    fun overlaps(a: ScheduleEntity, b: ScheduleEntity): Boolean {
        fun intervals(s: ScheduleEntity): List<IntArray> {
            val days: List<Int> = if (s.daysMask == 0) (0..6).toList()
            else (0..6).filter { ((s.daysMask shr it) and 1) == 1 }
            return days.map {
                val st = it * 1440 + s.startMinute
                intArrayOf(st, st + durationMinutes(s))
            }
        }
        val week = 10080
        for (x in intervals(a)) for (y in intervals(b)) for (shift in intArrayOf(-week, 0, week)) {
            if (x[0] < y[1] + shift && y[0] + shift < x[1]) return true
        }
        return false
    }

    fun daysLabel(mask: Int): String = when {
        mask == 0 -> "One time"
        (mask and 127) == 127 -> "Every day"
        else -> DAY_NAMES.filterIndexed { i, _ -> ((mask shr i) and 1) == 1 }.joinToString(", ")
    }

    fun timeLabel(minute: Int): String {
        val h24 = minute / 60
        val m = minute % 60
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        return String.format(Locale.US, "%02d:%02d %s", h12, m, if (h24 < 12) "AM" else "PM")
    }

    fun rangeLabel(s: ScheduleEntity) = "${timeLabel(s.startMinute)} – ${timeLabel(s.endMinute)}"
}

data class FocusStats(val completedToday: Int, val focusMsToday: Long, val streak: Int)

data class FullStats(
    val completed: Int,
    val interrupted: Int,
    val totalMs: Long,
    val todayMs: Long,
    val weekMs: Long,
    val streak: Int,
    val bestStreak: Int,
    val last7: List<Pair<LocalDate, Long>>
)

object StatsCalc {
    private fun day(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()

    private fun streakOf(days: Set<LocalDate>, today: LocalDate): Int {
        var d = if (today in days) today else today.minusDays(1)
        var streak = 0
        while (d in days) {
            streak++
            d = d.minusDays(1)
        }
        return streak
    }

    /** All numbers are derived from real session records only. */
    fun compute(sessions: List<SessionEntity>, nowMs: Long): FocusStats {
        val today = day(nowMs)
        val finished = sessions.filter { it.outcome != "ACTIVE" && it.endedMs != null }
        val todays = finished.filter { day(it.endedMs!!) == today }
        val completedToday = todays.count { it.outcome == "COMPLETED" }
        val focusMs = todays.sumOf { (it.endedMs!! - it.startMs).coerceAtLeast(0L) }
        val days = finished.filter { it.outcome == "COMPLETED" }.map { day(it.endedMs!!) }.toSet()
        return FocusStats(completedToday, focusMs, streakOf(days, today))
    }

    /** Sessions are attributed to the local day on which they ended. */
    fun full(sessions: List<SessionEntity>, nowMs: Long): FullStats {
        val today = day(nowMs)
        val finished = sessions.filter { it.outcome != "ACTIVE" && it.endedMs != null }
        fun dur(s: SessionEntity) = (s.endedMs!! - s.startMs).coerceAtLeast(0L)
        val perDay = finished.groupBy { day(it.endedMs!!) }.mapValues { e -> e.value.sumOf { dur(it) } }
        val last7 = (6 downTo 0).map { today.minusDays(it.toLong()) }.map { it to (perDay[it] ?: 0L) }
        val days = finished.filter { it.outcome == "COMPLETED" }.map { day(it.endedMs!!) }.toSet()
        var best = 0
        var run = 0
        var prev: LocalDate? = null
        for (d in days.sorted()) {
            run = if (prev != null && prev.plusDays(1) == d) run + 1 else 1
            if (run > best) best = run
            prev = d
        }
        return FullStats(
            completed = finished.count { it.outcome == "COMPLETED" },
            interrupted = finished.count { it.outcome == "INTERRUPTED" },
            totalMs = finished.sumOf { dur(it) },
            todayMs = perDay[today] ?: 0L,
            weekMs = last7.sumOf { it.second },
            streak = streakOf(days, today),
            bestStreak = best,
            last7 = last7
        )
    }

    fun formatDuration(ms: Long): String {
        val totalMin = ms / 60_000
        val h = totalMin / 60
        val m = totalMin % 60
        return if (h > 0) "${h}h ${m}m" else "${m}m"
    }

    fun formatClock(ms: Long): String {
        val total = (ms.coerceAtLeast(0L) + 999) / 1000
        return String.format(Locale.US, "%02d:%02d:%02d", total / 3600, (total % 3600) / 60, total % 60)
    }
}

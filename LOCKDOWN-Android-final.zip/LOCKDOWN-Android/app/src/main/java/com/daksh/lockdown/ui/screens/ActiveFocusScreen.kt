package com.daksh.lockdown.ui.screens

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daksh.lockdown.MainViewModel
import com.daksh.lockdown.apps.AppRepo
import com.daksh.lockdown.engine.Perms
import com.daksh.lockdown.logic.FocusState
import com.daksh.lockdown.logic.StatsCalc
import com.daksh.lockdown.ui.components.*
import com.daksh.lockdown.ui.theme.LocalLockdownColors
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * The launcher home screen while focus is on. Shows only the effective allowed apps.
 * It never traps the user: End focus is always one tap away, the system Home button always works,
 * and the emergency dialer is always shown.
 */
@Composable
fun ActiveFocusScreen(vm: MainViewModel, focus: FocusState, onManage: () -> Unit, onEditApps: () -> Unit) {
    val c = LocalLockdownColors.current
    val ctx = LocalContext.current
    val now by vm.now.collectAsState()
    val banner by vm.banner.collectAsState()
    val primary = focus.primary
    val isHome = remember { Perms.isDefaultHome(ctx) }
    var confirmEnd by remember { mutableStateOf(false) }

    // As the default Home app Back must not exit to nowhere; otherwise Back behaves normally.
    BackHandler(enabled = isHome) {
        vm.banner.value = "Focus is on. Use End focus to stop early."
    }

    val remaining = focus.endMs - now
    val total = ((primary?.plannedEndMs ?: 0L) - (primary?.startMs ?: 0L)).coerceAtLeast(1L)
    val progress = ((total - remaining).toFloat() / total.toFloat()).coerceIn(0f, 1f)
    val endLabel = remember(focus.endMs) {
        Instant.ofEpochMilli(focus.endMs).atZone(ZoneId.systemDefault())
            .format(DateTimeFormatter.ofPattern("hh:mm a", Locale.US))
    }
    val shown = focus.effectiveApps

    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.Lock, contentDescription = null, tint = c.accent, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("LOCKDOWN", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                }
                Text("FOCUS MODE ACTIVE", color = c.accentSoft, fontSize = 11.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(10.dp))
                FocusRing(progress, Modifier.fillMaxWidth(0.62f)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Time Remaining", color = c.textSecondary, fontSize = 13.sp)
                        Text(StatsCalc.formatClock(remaining), color = c.text, fontSize = 32.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                        Text(focus.title, color = c.textSecondary, fontSize = 13.sp, textAlign = TextAlign.Center, maxLines = 2)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("Ends at $endLabel  •  ${(progress * 100).toInt()}% done", color = c.textSecondary, fontSize = 13.sp)
            }
        }

        banner?.let { msg ->
            item(span = { GridItemSpan(maxLineSpan) }) { WarningCard(msg) }
        }

        if (focus.conflict) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                WarningCard(
                    if (focus.noAppsChosen) "No apps are allowed yet, so nothing can be shown."
                    else "The running schedules share no common allowed app, so no apps can be shown."
                ) {
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SecondaryButton("Edit apps", Modifier.weight(1f)) { onEditApps() }
                        PrimaryButton("End focus", Modifier.weight(1f)) { confirmEnd = true }
                    }
                }
            }
        } else {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text("Allowed apps", color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            }
            items(shown, key = { it }) { pkg ->
                AppTile(pkg, Modifier.fillMaxWidth(), 52.dp) {
                    if (!AppRepo.launch(ctx, pkg)) {
                        Toast.makeText(ctx, "That app is not available.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Spacer(Modifier.height(6.dp))
                // Emergency: always visible and never filtered (opens the dialer, no permission needed).
                PrimaryButton("Emergency call", Modifier.fillMaxWidth()) {
                    ctx.startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton("Open LOCKDOWN", Modifier.weight(1f)) { onManage() }
                    SecondaryButton("End focus", Modifier.weight(1f)) { confirmEnd = true }
                }
                Text(LIMITATION_TEXT, color = c.textSecondary, fontSize = 11.sp)
                Spacer(Modifier.height(12.dp))
            }
        }
    }

    if (confirmEnd) {
        ConfirmDialog(
            "End focus early?", "This will be recorded as an interrupted session.", "End focus",
            onConfirm = { vm.endFocus(); confirmEnd = false }, onDismiss = { confirmEnd = false }
        )
    }
}

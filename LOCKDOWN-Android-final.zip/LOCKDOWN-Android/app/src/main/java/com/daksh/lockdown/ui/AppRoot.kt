package com.daksh.lockdown.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.daksh.lockdown.MainViewModel
import com.daksh.lockdown.ui.home.HomeScreen
import com.daksh.lockdown.ui.screens.*
import com.daksh.lockdown.ui.theme.LocalLockdownColors

object Routes {
    const val HOME = "home"
    const val SCHEDULES = "schedules"
    const val ADD = "add"
    const val EDIT = "edit/{id}"
    const val APPS = "apps"
    const val STATS = "stats"
    const val SETTINGS = "settings"
    const val SETUP = "setup"
}

@Composable
fun AppRoot(
    vm: MainViewModel,
    dark: Boolean,
    startSetup: Boolean,
    onToggleTheme: () -> Unit,
    onSetupDone: () -> Unit
) {
    val c = LocalLockdownColors.current
    val nav = rememberNavController()
    val backEntry by nav.currentBackStackEntryAsState()
    val route = backEntry?.destination?.route ?: Routes.HOME

    val focus by vm.focusState.collectAsState()
    val homeEvent by vm.homeEvent.collectAsState()
    var manage by rememberSaveable { mutableStateOf(false) }

    // Return to the focus screen when focus ends or the Home button is pressed.
    LaunchedEffect(focus.isActive) { if (!focus.isActive) manage = false }
    LaunchedEffect(homeEvent) { if (homeEvent > 0) manage = false }
    LaunchedEffect(Unit) { if (startSetup) nav.navigate(Routes.SETUP) }

    fun go(r: String) {
        nav.navigate(r) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }
    fun edit(id: Long) = nav.navigate("edit/$id")

    val showFocus = focus.isActive && !manage && route != Routes.SETUP

    Column(Modifier.fillMaxSize().background(c.bg)) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            // NavHost is always composed so navigation works even while the focus screen is on top.
            Box(Modifier.fillMaxSize().then(if (route == Routes.SETUP) Modifier else Modifier.statusBarsPadding())) {
                NavHost(nav, startDestination = Routes.HOME) {
                    composable(Routes.HOME) {
                        HomeScreen(
                            vm, dark, onToggleTheme,
                            onNavigate = { if (it == Routes.ADD) edit(0) else go(it) },
                            onEditSchedule = { edit(it) }
                        )
                    }
                    composable(Routes.SCHEDULES) { SchedulesScreen(vm, onAdd = { edit(0) }, onEdit = { edit(it) }) }
                    composable(Routes.EDIT, arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
                        EditScheduleScreen(vm, e.arguments?.getLong("id") ?: 0L) { nav.popBackStack() }
                    }
                    composable(Routes.APPS) { AppsScreen(vm) }
                    composable(Routes.STATS) { StatsScreen(vm) }
                    composable(Routes.SETTINGS) {
                        SettingsScreen(vm, dark, onToggleTheme, onBack = { nav.popBackStack() }, onSetup = { nav.navigate(Routes.SETUP) })
                    }
                    composable(Routes.SETUP) {
                        SetupScreen(
                            onOpenApps = { nav.navigate(Routes.APPS) },
                            onOpenAddSchedule = { edit(0) },
                            onFinish = {
                                onSetupDone()
                                nav.navigate(Routes.HOME) {
                                    popUpTo(Routes.HOME) { inclusive = false }
                                    launchSingleTop = true
                                }
                            }
                        )
                    }
                }
            }
            if (showFocus) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(c.bg)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
                ) {
                    ActiveFocusScreen(
                        vm, focus,
                        onManage = { manage = true },
                        onEditApps = { manage = true; go(Routes.APPS) }
                    )
                }
            }
        }
        if (!showFocus && route != Routes.SETUP) {
            BottomBar(route = route, onGo = { if (it == Routes.ADD) edit(0) else go(it) })
        }
    }
}

@Composable
private fun BottomBar(route: String, onGo: (String) -> Unit) {
    val c = LocalLockdownColors.current
    Row(
        Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(c.card)
            .border(BorderStroke(1.dp, c.border), RoundedCornerShape(28.dp))
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NavItem("Home", Icons.Outlined.Home, route == Routes.HOME, Modifier.weight(1f)) { onGo(Routes.HOME) }
        NavItem("Schedules", Icons.Outlined.CalendarMonth, route == Routes.SCHEDULES, Modifier.weight(1f)) { onGo(Routes.SCHEDULES) }
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(58.dp).clip(CircleShape).background(c.accent).clickable { onGo(Routes.ADD) },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Outlined.Add, contentDescription = "Add schedule", tint = c.onAccent, modifier = Modifier.size(32.dp))
            }
        }
        NavItem("Apps", Icons.Outlined.Apps, route == Routes.APPS, Modifier.weight(1f)) { onGo(Routes.APPS) }
        NavItem("Stats", Icons.Outlined.BarChart, route == Routes.STATS, Modifier.weight(1f)) { onGo(Routes.STATS) }
    }
}

@Composable
private fun NavItem(label: String, icon: ImageVector, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val c = LocalLockdownColors.current
    val tint = if (selected) c.accentSoft else c.textSecondary
    Column(
        modifier.heightIn(min = 48.dp).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(26.dp))
        Text(label, color = tint, fontSize = 12.sp, maxLines = 1)
    }
}

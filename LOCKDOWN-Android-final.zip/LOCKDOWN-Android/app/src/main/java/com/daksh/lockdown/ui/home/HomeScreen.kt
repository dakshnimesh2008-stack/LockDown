package com.daksh.lockdown.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daksh.lockdown.MainViewModel
import com.daksh.lockdown.logic.FocusState
import com.daksh.lockdown.logic.FocusStats
import com.daksh.lockdown.logic.ScheduleLogic
import com.daksh.lockdown.logic.StatsCalc
import com.daksh.lockdown.ui.Routes
import com.daksh.lockdown.ui.components.*
import com.daksh.lockdown.ui.theme.CardShape
import com.daksh.lockdown.ui.theme.LocalLockdownColors
import com.daksh.lockdown.ui.theme.TileShape
import java.time.Instant
import java.time.ZoneId

@Composable
fun HomeScreen(
    vm: MainViewModel,
    dark: Boolean,
    onToggleTheme: () -> Unit,
    onNavigate: (String) -> Unit,
    onEditSchedule: (Long) -> Unit
) {
    val schedules by vm.schedules.collectAsState()
    val sessions by vm.sessions.collectAsState()
    val allowed by vm.allowed.collectAsState()
    val focus by vm.focusState.collectAsState()
    val now by vm.now.collectAsState()

    val stats = remember(sessions, focus.active.size) { StatsCalc.compute(sessions, System.currentTimeMillis()) }
    var showDurations by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<com.daksh.lockdown.data.ScheduleEntity?>(null) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(top = 8.dp, bottom = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Header(dark, onToggleTheme) { onNavigate(Routes.SETTINGS) }

        FocusCard(
            statusText = when {
                focus.isActive -> "Active Now"
                schedules.any { it.enabled } -> "Scheduled"
                else -> "Inactive"
            },
            focus = focus, now = now, stats = stats
        )

        if (focus.isActive && focus.conflict) {
            WarningCard(
                if (focus.noAppsChosen) "Focus is on but no apps are allowed yet."
                else "Overlapping schedules share no common allowed app. Edit the apps or end focus."
            )
        }

        QuickTiles(
            running = focus.isActive,
            onStartOrStop = { if (focus.isActive) vm.endFocus() else showDurations = true },
            onNavigate = onNavigate
        )

        UpcomingCard(
            schedules = schedules, now = now,
            onViewAll = { onNavigate(Routes.SCHEDULES) },
            onAdd = { onNavigate(Routes.ADD) },
            onToggle = { s, on -> vm.setScheduleEnabled(s, on) },
            onEdit = onEditSchedule,
            onDuplicate = { vm.duplicateSchedule(it) },
            onDelete = { toDelete = it }
        )

        AllowedAppsCard(allowed.map { it.packageName }, onEdit = { onNavigate(Routes.APPS) })
    }

    if (showDurations) {
        DurationDialog(
            onDismiss = { showDurations = false },
            onPick = { vm.startManual(it); showDurations = false }
        )
    }
    toDelete?.let { s ->
        ConfirmDialog(
            "Delete schedule?", "\"${s.name}\" will be removed. A running session for it will be ended.",
            "Delete", onConfirm = { vm.deleteSchedule(s); toDelete = null }, onDismiss = { toDelete = null }
        )
    }
}

@Composable
private fun Header(dark: Boolean, onToggleTheme: () -> Unit, onSettings: () -> Unit) {
    val c = LocalLockdownColors.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Lock, contentDescription = null, tint = c.accent, modifier = Modifier.size(26.dp))
                Spacer(Modifier.width(6.dp))
                Text("LOCKDOWN", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp, maxLines = 1)
            }
            Text("FOCUS TODAY. BETTER TOMORROW.", color = c.textSecondary, fontSize = 9.sp, letterSpacing = 2.sp, maxLines = 1)
        }
        Row(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(c.tile)
                .border(1.dp, c.accent.copy(alpha = 0.7f), RoundedCornerShape(50))
                .clickable(onClick = onToggleTheme)
                .padding(4.dp)
                .semantics { contentDescription = "Switch theme" },
            verticalAlignment = Alignment.CenterVertically
        ) {
            ThemeKnob(Icons.Outlined.DarkMode, selected = dark)
            ThemeKnob(Icons.Outlined.LightMode, selected = !dark)
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(c.tile)
                .border(1.dp, c.border, CircleShape)
                .clickable(onClick = onSettings),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Outlined.Settings, contentDescription = "Settings", tint = c.text)
        }
    }
}

@Composable
private fun ThemeKnob(icon: ImageVector, selected: Boolean) {
    val c = LocalLockdownColors.current
    Box(
        Modifier.size(34.dp).clip(CircleShape).background(if (selected) c.accent else Color.Transparent),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = if (selected) c.onAccent else c.textSecondary, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun FocusCard(statusText: String, focus: FocusState, now: Long, stats: FocusStats) {
    val c = LocalLockdownColors.current
    val primary = focus.primary
    val remaining = if (focus.isActive) focus.endMs - now else 0L
    val progress = if (primary != null && focus.isActive) {
        (remaining.toFloat() / (primary.plannedEndMs - primary.startMs).coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f)
    } else 0f

    Column(
        Modifier
            .fillMaxWidth()
            .clip(CardShape)
            .background(Brush.verticalGradient(listOf(c.accent.copy(alpha = 0.16f), c.card)))
            .border(1.5.dp, c.accent.copy(alpha = 0.7f), CardShape)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(14.dp).clip(CircleShape).background(c.accent))
            Spacer(Modifier.width(8.dp))
            Text("Focus Mode", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            Text(statusText, color = c.accentSoft, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(8.dp))
        FocusRing(progress, Modifier.fillMaxWidth(0.78f).align(Alignment.CenterHorizontally)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (focus.isActive) "Time Remaining" else "Ready to focus", color = c.textSecondary, fontSize = 15.sp)
                Text(StatsCalc.formatClock(remaining), color = c.text, fontSize = 38.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                Icon(Icons.Outlined.MenuBook, contentDescription = null, tint = c.textSecondary, modifier = Modifier.size(24.dp))
                Text(
                    if (focus.isActive) focus.title else "No active session",
                    color = c.textSecondary, fontSize = 15.sp, textAlign = TextAlign.Center, maxLines = 2
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), verticalAlignment = Alignment.CenterVertically) {
            StatItem(Icons.Outlined.RadioButtonChecked, "${stats.completedToday}", "Today's Sessions", Modifier.weight(1f))
            VDivider()
            StatItem(Icons.Outlined.BarChart, StatsCalc.formatDuration(stats.focusMsToday), "Focus Time", Modifier.weight(1f))
            VDivider()
            StatItem(Icons.Outlined.LocalFireDepartment, "${stats.streak}", "Day Streak", Modifier.weight(1f))
        }
    }
}

@Composable
private fun VDivider() {
    val c = LocalLockdownColors.current
    Box(Modifier.width(1.dp).fillMaxHeight().padding(vertical = 4.dp).background(c.border))
}

@Composable
private fun StatItem(icon: ImageVector, value: String, label: String, modifier: Modifier) {
    val c = LocalLockdownColors.current
    Row(modifier.padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        Icon(icon, contentDescription = null, tint = c.textSecondary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(6.dp))
        Column {
            Text(value, color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            Text(label, color = c.textSecondary, fontSize = 11.sp, maxLines = 1)
        }
    }
}

@Composable
private fun QuickTiles(running: Boolean, onStartOrStop: () -> Unit, onNavigate: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Tile(
            icon = if (running) Icons.Outlined.StopCircle else Icons.Outlined.PlayCircle,
            title = if (running) "End Focus" else "Start Focus",
            sub = if (running) "Stops session" else "Manual Session",
            filled = true, modifier = Modifier.weight(1.15f), onClick = onStartOrStop
        )
        Tile(Icons.Outlined.CalendarMonth, "Add Schedule", null, false, Modifier.weight(1f)) { onNavigate(Routes.ADD) }
        Tile(Icons.Outlined.Apps, "Allowed Apps", null, false, Modifier.weight(1f)) { onNavigate(Routes.APPS) }
        Tile(Icons.Outlined.BarChart, "Statistics", null, false, Modifier.weight(1f)) { onNavigate(Routes.STATS) }
    }
}

@Composable
private fun Tile(icon: ImageVector, title: String, sub: String?, filled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val c = LocalLockdownColors.current
    Column(
        modifier
            .fillMaxHeight()
            .heightIn(min = 92.dp)
            .clip(TileShape)
            .background(if (filled) c.accent else c.tile)
            .border(1.dp, if (filled) c.accent else c.border, TileShape)
            .clickable(onClick = onClick)
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, contentDescription = null, tint = if (filled) c.onAccent else c.text, modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(6.dp))
        Text(title, color = if (filled) c.onAccent else c.text, fontSize = 12.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.Medium)
        if (sub != null) Text(sub, color = c.onAccent.copy(alpha = 0.75f), fontSize = 10.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun UpcomingCard(
    schedules: List<com.daksh.lockdown.data.ScheduleEntity>,
    now: Long,
    onViewAll: () -> Unit,
    onAdd: () -> Unit,
    onToggle: (com.daksh.lockdown.data.ScheduleEntity, Boolean) -> Unit,
    onEdit: (Long) -> Unit,
    onDuplicate: (com.daksh.lockdown.data.ScheduleEntity) -> Unit,
    onDelete: (com.daksh.lockdown.data.ScheduleEntity) -> Unit
) {
    val zdt = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault())
    val upcoming = remember(schedules, now / 60_000) {
        schedules
            .map { it to ScheduleLogic.nextStart(it, zdt) }
            .sortedWith(compareBy({ !it.first.enabled }, { it.second?.toEpochSecond() ?: Long.MAX_VALUE }))
            .map { it.first }
            .take(2)
    }
    SectionCard {
        SectionHeader("Upcoming Schedules", null, "View All", onViewAll)
        Spacer(Modifier.height(8.dp))
        if (upcoming.isEmpty()) {
            EmptyState("No schedules yet", "Create a focus schedule for study, work or sleep.", "Add Schedule", onAdd)
        } else {
            val c = LocalLockdownColors.current
            upcoming.forEachIndexed { i, s ->
                if (i > 0) HorizontalDivider(color = c.border)
                ScheduleRow(s, { onToggle(s, it) }, { onEdit(s.id) }, { onDuplicate(s) }, { onDelete(s) })
            }
        }
    }
}

@Composable
private fun AllowedAppsCard(packages: List<String>, onEdit: () -> Unit) {
    SectionCard {
        SectionHeader("Allowed Apps", "(During Focus)", "Edit", onEdit)
        Spacer(Modifier.height(8.dp))
        if (packages.isEmpty()) {
            EmptyState("No apps selected yet", "Choose which apps stay available during focus.", "Add Apps", onEdit)
        } else {
            val c = LocalLockdownColors.current
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                packages.take(5).forEach { AppTile(it, Modifier.weight(1f), 48.dp) }
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).clickable(onClick = onEdit).padding(4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(c.tile).border(1.dp, c.border, RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Outlined.Add, contentDescription = "Add app", tint = c.text) }
                    Spacer(Modifier.height(4.dp))
                    Text(if (packages.size > 5) "+${packages.size - 5} more" else "Add", color = c.text, fontSize = 12.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun DurationDialog(onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    val c = LocalLockdownColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        title = { Text("Start focus session", color = c.text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(25, 45, 60, 90).forEach { m ->
                    OutlinedButton(onClick = { onPick(m) }, modifier = Modifier.fillMaxWidth()) {
                        Text("$m minutes", color = c.text)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.accentSoft) } }
    )
}

package com.daksh.lockdown.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A focus schedule.
 * startMinute / endMinute: minutes since midnight (0..1439). If end <= start the schedule crosses midnight.
 * daysMask: bit0 = Monday ... bit6 = Sunday. 0 means one-time (runs once, then disables itself).
 * allowedPackages: null = use the full allowed-app list; otherwise a comma separated subset.
 */
@Entity(tableName = "schedules")
data class ScheduleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val startMinute: Int,
    val endMinute: Int,
    val daysMask: Int,
    val enabled: Boolean = true,
    val icon: String = "book",
    val notify: Boolean = true,
    val allowedPackages: String? = null
)

/** A focus session record. outcome: ACTIVE, COMPLETED or INTERRUPTED. */
@Entity(tableName = "sessions")
data class SessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val scheduleId: Long?,
    val name: String,
    val startMs: Long,
    val plannedEndMs: Long,
    val endedMs: Long?,
    val outcome: String
)

/** The global allowed-app whitelist, in the user's chosen order. */
@Entity(tableName = "allowed_apps")
data class AllowedAppEntity(
    @PrimaryKey val packageName: String,
    val position: Int
)

package com.daksh.lockdown.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class LockdownColors(
    val bg: Color,
    val card: Color,
    val tile: Color,
    val border: Color,
    val accent: Color,
    val accentSoft: Color,
    val onAccent: Color,
    val text: Color,
    val textSecondary: Color
)

val DarkLockdownColors = LockdownColors(
    bg = Color(0xFF000000),
    card = Color(0xFF0B0B10),
    tile = Color(0xFF12121A),
    border = Color(0xFF2A2A33),
    accent = Color(0xFF8B3DFF),
    accentSoft = Color(0xFFA678FF),
    onAccent = Color(0xFFFFFFFF),
    text = Color(0xFFFFFFFF),
    textSecondary = Color(0xFF9A9AA8)
)

val LightLockdownColors = LockdownColors(
    bg = Color(0xFFF5F4F8),
    card = Color(0xFFFFFFFF),
    tile = Color(0xFFEFEDF5),
    border = Color(0xFFDEDBE8),
    accent = Color(0xFF6A1BD1),
    accentSoft = Color(0xFF7C3AE0),
    onAccent = Color(0xFFFFFFFF),
    text = Color(0xFF14121A),
    textSecondary = Color(0xFF65627A)
)

val LocalLockdownColors = staticCompositionLocalOf { DarkLockdownColors }

val CardShape = RoundedCornerShape(24.dp)
val TileShape = RoundedCornerShape(20.dp)

@Composable
fun LockdownTheme(dark: Boolean, content: @Composable () -> Unit) {
    val c = if (dark) DarkLockdownColors else LightLockdownColors
    val scheme = if (dark) {
        darkColorScheme(
            primary = c.accent, onPrimary = c.onAccent,
            background = c.bg, onBackground = c.text,
            surface = c.card, onSurface = c.text,
            outline = c.border
        )
    } else {
        lightColorScheme(
            primary = c.accent, onPrimary = c.onAccent,
            background = c.bg, onBackground = c.text,
            surface = c.card, onSurface = c.text,
            outline = c.border
        )
    }
    CompositionLocalProvider(LocalLockdownColors provides c) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

@file:OptIn(ExperimentalMaterial3Api::class)

package com.daksh.lockdown.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.daksh.lockdown.apps.AppRepo
import com.daksh.lockdown.apps.IconCache
import com.daksh.lockdown.data.ScheduleEntity
import com.daksh.lockdown.logic.ScheduleLogic
import com.daksh.lockdown.ui.theme.CardShape
import com.daksh.lockdown.ui.theme.LocalLockdownColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

const val LIMITATION_TEXT =
    "LOCKDOWN is a focus launcher. It shows only your allowed apps while focus is on, but Android does not let " +
        "a launcher block Recent Apps, system Settings, the notification shade or other launchers. " +
        "Emergency calls always stay available."

fun iconFor(key: String): ImageVector = when (key) {
    "moon" -> Icons.Outlined.Bedtime
    "work" -> Icons.Outlined.Work
    "book" -> Icons.Outlined.MenuBook
    else -> Icons.Outlined.Timer
}

val ICON_KEYS = listOf("book", "moon", "work", "timer")

@Composable
fun rememberResumeTick(): Int {
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return tick
}

@Composable
fun ScreenTitle(title: String, onBack: (() -> Unit)? = null) {
    val c = LocalLockdownColors.current
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back", tint = c.text)
            }
        }
        Text(title, color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SectionCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val c = LocalLockdownColors.current
    Column(
        modifier
            .fillMaxWidth()
            .clip(CardShape)
            .background(c.card)
            .border(1.dp, c.border, CardShape)
            .padding(14.dp),
        content = content
    )
}

@Composable
fun SectionHeader(title: String, sub: String? = null, action: String, onAction: () -> Unit) {
    val c = LocalLockdownColors.current
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        if (sub != null) {
            Spacer(Modifier.width(6.dp))
            Text(sub, color = c.textSecondary, fontSize = 14.sp)
        }
        Spacer(Modifier.weight(1f))
        Row(
            Modifier
                .clip(RoundedCornerShape(50))
                .background(c.tile)
                .clickable(onClick = onAction)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(action, color = c.accentSoft, fontSize = 14.sp)
            Icon(Icons.Outlined.ChevronRight, contentDescription = null, tint = c.accentSoft, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = LocalLockdownColors.current
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 48.dp),
        colors = ButtonDefaults.buttonColors(containerColor = c.accent, contentColor = c.onAccent)
    ) { Text(text) }
}

@Composable
fun SecondaryButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = LocalLockdownColors.current
    OutlinedButton(onClick = onClick, modifier = modifier.heightIn(min = 48.dp)) {
        Text(text, color = c.accentSoft)
    }
}

@Composable
fun EmptyState(title: String, sub: String, action: String?, onAction: () -> Unit) {
    val c = LocalLockdownColors.current
    Column(Modifier.fillMaxWidth().padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(4.dp))
        Text(sub, color = c.textSecondary, fontSize = 13.sp, textAlign = TextAlign.Center)
        if (action != null) {
            Spacer(Modifier.height(10.dp))
            PrimaryButton(action, onClick = onAction)
        }
    }
}

@Composable
fun WarningCard(text: String, content: @Composable ColumnScope.() -> Unit = {}) {
    val c = LocalLockdownColors.current
    val warn = Color(0xFFFFB020)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(warn.copy(alpha = 0.12f))
            .border(1.dp, warn.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Icon(Icons.Outlined.Warning, contentDescription = null, tint = warn, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(text, color = c.text, fontSize = 13.sp)
        }
        content()
    }
}

/** The glowing circular progress ring. [progress] is the filled fraction (0..1). */
@Composable
fun FocusRing(progress: Float, modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val c = LocalLockdownColors.current
    Box(modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 14.dp.toPx()
            val inset = stroke / 2 + 8.dp.toPx()
            val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
            val topLeft = Offset(inset, inset)
            drawArc(c.border, -90f, 360f, false, topLeft, arcSize, style = Stroke(stroke))
            if (progress > 0f) {
                drawArc(
                    c.accent.copy(alpha = 0.25f), -90f, 360f * progress, false, topLeft, arcSize,
                    style = Stroke(stroke + 12.dp.toPx(), cap = StrokeCap.Round)
                )
                drawArc(
                    c.accent, -90f, 360f * progress, false, topLeft, arcSize,
                    style = Stroke(stroke, cap = StrokeCap.Round)
                )
            }
        }
        content()
    }
}

@Composable
fun AppIcon(pkg: String, size: Dp) {
    val c = LocalLockdownColors.current
    val ctx = LocalContext.current
    val img by produceState<ImageBitmap?>(IconCache.cached(pkg), pkg) {
        if (value == null) value = withContext(Dispatchers.Default) { IconCache.load(ctx, pkg) }
    }
    val shape = RoundedCornerShape(14.dp)
    if (img != null) {
        Image(bitmap = img!!, contentDescription = null, modifier = Modifier.size(size).clip(shape))
    } else {
        Box(Modifier.size(size).clip(shape).background(c.tile).border(1.dp, c.border, shape), contentAlignment = Alignment.Center) {
            Icon(Icons.Outlined.Apps, contentDescription = null, tint = c.textSecondary, modifier = Modifier.size(size / 2))
        }
    }
}

/** Icon + label of a real installed app. Shows "Not installed" if it has been removed. */
@Composable
fun AppTile(pkg: String, modifier: Modifier = Modifier, iconSize: Dp = 56.dp, onClick: (() -> Unit)? = null) {
    val c = LocalLockdownColors.current
    val ctx = LocalContext.current
    val label by produceState<String?>(null, pkg) {
        value = withContext(Dispatchers.Default) { AppRepo.label(ctx, pkg) }
    }
    Column(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIcon(pkg, iconSize)
        Spacer(Modifier.height(4.dp))
        Text(
            label ?: "Not installed", color = if (label == null) c.textSecondary else c.text,
            fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
        )
    }
}

@Composable
fun ScheduleRow(
    s: ScheduleEntity,
    onToggle: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onDuplicate: (() -> Unit)?,
    onDelete: () -> Unit
) {
    val c = LocalLockdownColors.current
    var menu by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(c.tile),
            contentAlignment = Alignment.Center
        ) { Icon(iconFor(s.icon), contentDescription = null, tint = c.text, modifier = Modifier.size(28.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f).clickable(onClick = onEdit)) {
            Text(s.name, color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                ScheduleLogic.rangeLabel(s) + if (ScheduleLogic.crossesMidnight(s)) " (+1)" else "",
                color = c.textSecondary, fontSize = 13.sp, maxLines = 1
            )
            Text(ScheduleLogic.daysLabel(s.daysMask), color = c.textSecondary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Switch(
            checked = s.enabled,
            onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White, checkedTrackColor = c.accent,
                uncheckedThumbColor = c.textSecondary, uncheckedTrackColor = c.tile, uncheckedBorderColor = c.border
            )
        )
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Outlined.MoreVert, contentDescription = "More options", tint = c.textSecondary)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Edit") }, onClick = { menu = false; onEdit() })
                if (onDuplicate != null) {
                    DropdownMenuItem(text = { Text("Duplicate") }, onClick = { menu = false; onDuplicate() })
                }
                DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; onDelete() })
            }
        }
    }
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val c = LocalLockdownColors.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.card,
        title = { Text(title, color = c.text) },
        text = { Text(text, color = c.textSecondary) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirm, color = c.accentSoft) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = c.textSecondary) } }
    )
}

@Composable
fun AppLabelText(pkg: String) {
    val c = LocalLockdownColors.current
    val ctx = LocalContext.current
    val label by produceState<String?>(null, pkg) {
        value = withContext(Dispatchers.Default) { AppRepo.label(ctx, pkg) }
    }
    Text(label ?: "Not installed", color = if (label == null) c.textSecondary else c.text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
}

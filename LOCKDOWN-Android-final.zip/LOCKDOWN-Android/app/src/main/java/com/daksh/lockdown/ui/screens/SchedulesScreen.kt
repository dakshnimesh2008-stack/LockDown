package com.daksh.lockdown.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.daksh.lockdown.MainViewModel
import com.daksh.lockdown.data.ScheduleEntity
import com.daksh.lockdown.ui.components.*

@Composable
fun SchedulesScreen(vm: MainViewModel, onAdd: () -> Unit, onEdit: (Long) -> Unit) {
    val schedules by vm.schedules.collectAsState()
    var toDelete by remember { mutableStateOf<ScheduleEntity?>(null) }
    val sorted = remember(schedules) { schedules.sortedWith(compareBy({ it.startMinute }, { it.name })) }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        item { ScreenTitle("Schedules") }
        if (sorted.isEmpty()) {
            item {
                SectionCard {
                    EmptyState(
                        "No schedules yet",
                        "Create unlimited focus schedules, like alarms, for study, work or sleep.",
                        "Add Schedule", onAdd
                    )
                }
            }
        } else {
            items(sorted, key = { it.id }) { s ->
                SectionCard {
                    ScheduleRow(
                        s,
                        onToggle = { vm.setScheduleEnabled(s, it) },
                        onEdit = { onEdit(s.id) },
                        onDuplicate = { vm.duplicateSchedule(s) },
                        onDelete = { toDelete = s }
                    )
                }
            }
        }
    }

    toDelete?.let { s ->
        ConfirmDialog(
            "Delete schedule?", "\"${s.name}\" will be removed. A running session for it will be ended.",
            "Delete", onConfirm = { vm.deleteSchedule(s); toDelete = null }, onDismiss = { toDelete = null }
        )
    }
}

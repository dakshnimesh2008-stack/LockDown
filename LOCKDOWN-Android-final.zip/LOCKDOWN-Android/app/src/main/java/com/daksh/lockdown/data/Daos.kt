package com.daksh.lockdown.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ScheduleDao {
    @Query("SELECT * FROM schedules ORDER BY id DESC")
    fun observeAll(): Flow<List<ScheduleEntity>>

    @Query("SELECT * FROM schedules")
    suspend fun getAll(): List<ScheduleEntity>

    @Query("SELECT * FROM schedules WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): ScheduleEntity?

    @Insert
    suspend fun insert(s: ScheduleEntity): Long

    @Update
    suspend fun update(s: ScheduleEntity)

    @Delete
    suspend fun delete(s: ScheduleEntity)
}

@Dao
interface SessionDao {
    @Query("SELECT * FROM sessions ORDER BY startMs DESC")
    fun observeAll(): Flow<List<SessionEntity>>

    @Query("SELECT * FROM sessions WHERE outcome = 'ACTIVE'")
    suspend fun getActiveList(): List<SessionEntity>

    @Query("SELECT * FROM sessions WHERE scheduleId = :sid AND startMs = :start LIMIT 1")
    suspend fun find(sid: Long, start: Long): SessionEntity?

    @Insert
    suspend fun insert(s: SessionEntity): Long

    @Update
    suspend fun update(s: SessionEntity)

    @Query("DELETE FROM sessions WHERE outcome != 'ACTIVE'")
    suspend fun clearFinished()
}

@Dao
abstract class AllowedAppDao {
    @Query("SELECT * FROM allowed_apps ORDER BY position ASC")
    abstract fun observeAll(): Flow<List<AllowedAppEntity>>

    @Query("DELETE FROM allowed_apps")
    abstract suspend fun clear()

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertAll(list: List<AllowedAppEntity>)

    @Transaction
    open suspend fun replaceAll(list: List<AllowedAppEntity>) {
        clear()
        insertAll(list)
    }
}

package com.daksh.lockdown

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.datastore.preferences.core.edit
import androidx.lifecycle.lifecycleScope
import com.daksh.lockdown.data.Prefs
import com.daksh.lockdown.data.dataStore
import com.daksh.lockdown.ui.AppRoot
import com.daksh.lockdown.ui.theme.LockdownTheme
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Read saved preferences before the first frame so the wrong theme never flashes.
        val initial = runBlocking { applicationContext.dataStore.data.first() }
        val initialDark = initial[Prefs.DARK_THEME] ?: true
        val setupDone = initial[Prefs.SETUP_DONE] ?: false

        setContent {
            val flow = remember { applicationContext.dataStore.data.map { it[Prefs.DARK_THEME] ?: true } }
            val dark by flow.collectAsState(initial = initialDark)

            val view = LocalView.current
            SideEffect {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }

            LockdownTheme(dark = dark) {
                AppRoot(
                    vm = vm,
                    dark = dark,
                    startSetup = !setupDone,
                    onToggleTheme = {
                        lifecycleScope.launch {
                            applicationContext.dataStore.edit { it[Prefs.DARK_THEME] = !dark }
                        }
                    },
                    onSetupDone = {
                        lifecycleScope.launch {
                            applicationContext.dataStore.edit { it[Prefs.SETUP_DONE] = true }
                        }
                    }
                )
            }
        }
    }

    override fun onStart() {
        super.onStart()
        vm.refreshApps()
        vm.syncNow()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Home button / failed launch of a non-allowed app lands here.
        if (intent.hasCategory(Intent.CATEGORY_HOME)) vm.onHomePressed()
    }
}

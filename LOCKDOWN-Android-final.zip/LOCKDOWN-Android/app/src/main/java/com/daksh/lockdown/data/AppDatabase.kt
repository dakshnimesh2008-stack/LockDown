package com.daksh.lockdown.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [ScheduleEntity::class, SessionEntity::class, AllowedAppEntity::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun scheduleDao(): ScheduleDao
    abstract fun sessionDao(): SessionDao
    abstract fun allowedAppDao(): AllowedAppDao
}

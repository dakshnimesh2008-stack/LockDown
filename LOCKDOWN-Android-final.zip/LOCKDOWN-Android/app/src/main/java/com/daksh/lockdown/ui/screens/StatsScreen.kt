package com.daksh.lockdown.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daksh.lockdown.MainViewModel
import com.daksh.lockdown.logic.StatsCalc
import com.daksh.lockdown.ui.components.*
import com.daksh.lockdown.ui.theme.LocalLockdownColors
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun StatsScreen(vm: MainViewModel) {
    val c = LocalLockdownColors.current
    val sessions by vm.sessions.collectAsState()
    val stats = remember(sessions) { StatsCalc.full(sessions, System.currentTimeMillis()) }
    var confirm by remember { mutableStateOf(false) }
    val max = (stats.last7.maxOfOrNull { it.second } ?: 0L).coerceAtLeast(1L)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle("Statistics")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Completed", "${stats.completed}", Modifier.weight(1f))
            Stat("Interrupted", "${stats.interrupted}", Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Today", StatsCalc.formatDuration(stats.todayMs), Modifier.weight(1f))
            Stat("Last 7 days", StatsCalc.formatDuration(stats.weekMs), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Current streak", "${stats.streak} d", Modifier.weight(1f))
            Stat("Best streak", "${stats.bestStreak} d", Modifier.weight(1f))
        }
        Stat("Total focus time", StatsCalc.formatDuration(stats.totalMs), Modifier.fillMaxWidth())

        SectionCard {
            Text("Focus time, last 7 days", color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().height(110.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.SpaceEvenly) {
                stats.last7.forEach { (_, ms) ->
                    Box(
                        Modifier.width(22.dp)
                            .height((100 * ms.toFloat() / max.toFloat()).dp.coerceAtLeast(3.dp))
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (ms > 0) c.accent else c.border)
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                stats.last7.forEach { (d, _) ->
                    Text(
                        d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault()).take(3),
                        color = c.textSecondary, fontSize = 11.sp, modifier = Modifier.width(30.dp)
                    )
                }
            }
        }

        Text(
            "Numbers come only from sessions recorded by LOCKDOWN. A session counts on the day it ended. " +
                "LOCKDOWN does not measure total phone usage.",
            color = c.textSecondary, fontSize = 12.sp
        )
        SecondaryButton("Clear statistics", Modifier.fillMaxWidth()) { confirm = true }
    }

    if (confirm) {
        ConfirmDialog(
            "Clear statistics?", "All completed and interrupted session history will be deleted from this device.",
            "Clear", onConfirm = { vm.clearStats(); confirm = false }, onDismiss = { confirm = false }
        )
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) {
    val c = LocalLockdownColors.current
    SectionCard(modifier) {
        Text(value, color = c.text, fontSize = 26.sp, fontWeight = FontWeight.SemiBold)
        Text(label, color = c.textSecondary, fontSize = 13.sp)
    }
}

@file:OptIn(ExperimentalMaterial3Api::class)

package com.daksh.lockdown.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daksh.lockdown.MainViewModel
import com.daksh.lockdown.ui.components.*
import com.daksh.lockdown.ui.theme.LocalLockdownColors

@Composable
fun AppsScreen(vm: MainViewModel) {
    val c = LocalLockdownColors.current
    val allowed by vm.allowed.collectAsState()
    val installed by vm.installedApps.collectAsState()
    var query by remember { mutableStateOf("") }
    val selected = remember(allowed) { allowed.map { it.packageName } }
    val filtered = remember(installed, query) {
        installed.filter { query.isBlank() || it.label.contains(query.trim(), ignoreCase = true) }
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        item { ScreenTitle("Allowed Apps") }
        item {
            Text(
                "These apps stay available during focus. Changes are saved automatically.",
                color = c.textSecondary, fontSize = 13.sp
            )
        }
        item { Column { Spacer(Modifier.height(6.dp)); Text("Selected (${selected.size})", color = c.text, fontSize = 18.sp) } }
        if (selected.isEmpty()) {
            item {
                SectionCard {
                    EmptyState("No apps selected", "Tick apps below. Phone and a calculator are good starters.", null) {}
                }
            }
        } else {
            items(selected, key = { "sel-$it" }) { pkg ->
                SectionCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        AppIcon(pkg, 40.dp)
                        Spacer(Modifier.width(10.dp))
                        Box(Modifier.weight(1f)) { AppLabelText(pkg) }
                        IconButton(onClick = { vm.moveApp(pkg, -1) }, enabled = selected.first() != pkg) {
                            Icon(Icons.Outlined.ArrowUpward, contentDescription = "Move up")
                        }
                        IconButton(onClick = { vm.moveApp(pkg, 1) }, enabled = selected.last() != pkg) {
                            Icon(Icons.Outlined.ArrowDownward, contentDescription = "Move down")
                        }
                        IconButton(onClick = { vm.toggleApp(pkg) }) {
                            Icon(Icons.Outlined.Close, contentDescription = "Remove")
                        }
                    }
                }
            }
        }
        item {
          Column {
            Spacer(Modifier.height(10.dp))
            Text("Installed apps", color = c.text, fontSize = 18.sp)
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text("Search apps") }, singleLine = true,
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = c.accent, unfocusedBorderColor = c.border)
            )
          }
        }
        if (filtered.isEmpty()) {
            item {
                Text(
                    if (installed.isEmpty()) "Loading apps…" else "No apps match your search.",
                    color = c.textSecondary, modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        }
        items(filtered, key = { "app-${it.packageName}" }) { app ->
            val on = app.packageName in selected
            Row(
                Modifier.fillMaxWidth().heightIn(min = 52.dp).clickable { vm.toggleApp(app.packageName) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                AppIcon(app.packageName, 40.dp)
                Spacer(Modifier.width(12.dp))
                Text(app.label, color = c.text, modifier = Modifier.weight(1f), maxLines = 1, fontSize = 16.sp)
                Checkbox(checked = on, onCheckedChange = { vm.toggleApp(app.packageName) })
            }
        }
    }
}

package com.daksh.lockdown.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Handles our alarm AND recovery broadcasts: boot, app update, manual clock change,
 * time-zone change and exact-alarm permission changes. All of them just re-run sync().
 */
class FocusReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                FocusEngine.sync(context.applicationContext)
            } finally {
                pending.finish()
            }
        }
    }
}

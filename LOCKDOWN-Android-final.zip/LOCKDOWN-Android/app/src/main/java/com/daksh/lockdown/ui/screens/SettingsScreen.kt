package com.daksh.lockdown.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daksh.lockdown.MainViewModel
import com.daksh.lockdown.engine.Perms
import com.daksh.lockdown.ui.components.*
import com.daksh.lockdown.ui.theme.LocalLockdownColors

fun openSafely(ctx: Context, intent: Intent) {
    try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e2: Exception) {
        }
    }
}

fun homeSettingsIntent() = Intent(Settings.ACTION_HOME_SETTINGS)

fun exactAlarmIntent(ctx: Context): Intent =
    if (Build.VERSION.SDK_INT >= 31)
        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}"))
    else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))

fun notificationSettingsIntent(ctx: Context): Intent =
    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)

@Composable
fun PermissionRow(title: String, why: String, granted: Boolean, button: String, onClick: () -> Unit) {
    val c = LocalLockdownColors.current
    SectionCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (granted) Icons.Outlined.CheckCircle else Icons.Outlined.ErrorOutline,
                contentDescription = if (granted) "Granted" else "Not granted",
                tint = if (granted) Color(0xFF3DDC84) else Color(0xFFFFB020)
            )
            Spacer(Modifier.width(10.dp))
            Text(title, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Text(if (granted) "On" else "Off", color = c.textSecondary, fontSize = 13.sp)
        }
        Spacer(Modifier.height(4.dp))
        Text(why, color = c.textSecondary, fontSize = 13.sp)
        if (!granted) {
            Spacer(Modifier.height(8.dp))
            SecondaryButton(button, onClick = onClick)
        }
    }
}

@Composable
fun SettingsScreen(
    vm: MainViewModel,
    dark: Boolean,
    onToggleTheme: () -> Unit,
    onBack: () -> Unit,
    onSetup: () -> Unit
) {
    val c = LocalLockdownColors.current
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    var refresh by remember { mutableIntStateOf(0) }
    val notif = remember(tick, refresh) { Perms.notificationsGranted(ctx) }
    val exact = remember(tick, refresh) { Perms.canExactAlarms(ctx) }
    val home = remember(tick, refresh) { Perms.isDefaultHome(ctx) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }
    var confirmAll by remember { mutableStateOf(false) }
    var confirmStats by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle("Settings", onBack)

        SectionCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Dark AMOLED theme", color = c.text, fontSize = 16.sp)
                    Text("Turn off for the Bright theme", color = c.textSecondary, fontSize = 12.sp)
                }
                Switch(checked = dark, onCheckedChange = { onToggleTheme() })
            }
        }

        Text("Permissions and launcher", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        PermissionRow(
            "Default Home app", "Lets LOCKDOWN replace your home screen during focus. Optional, but needed for the launcher experience.",
            home, "Open Home settings"
        ) { openSafely(ctx, homeSettingsIntent()) }
        PermissionRow(
            "Notifications", "Used only to tell you when a focus session starts or ends. Optional.",
            notif, "Allow"
        ) {
            if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
            else openSafely(ctx, notificationSettingsIntent(ctx))
        }
        PermissionRow(
            "Exact alarms", "Starts and ends sessions on the exact minute. Without it LOCKDOWN uses inexact alarms and may be a little late.",
            exact, "Open alarm settings"
        ) { openSafely(ctx, exactAlarmIntent(ctx)) }
        if (!notif) {
            SecondaryButton("Open notification settings", Modifier.fillMaxWidth()) {
                openSafely(ctx, notificationSettingsIntent(ctx))
            }
        }

        SecondaryButton("Run setup guide again", Modifier.fillMaxWidth(), onSetup)

        Text("Your data", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Text("Everything is stored only on this device. No account, ads, analytics or internet access.", color = c.textSecondary, fontSize = 13.sp)
        SecondaryButton("Clear statistics", Modifier.fillMaxWidth()) { confirmStats = true }
        SecondaryButton("Delete all LOCKDOWN data", Modifier.fillMaxWidth()) { confirmAll = true }

        Text("Limitations", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Text(LIMITATION_TEXT, color = c.textSecondary, fontSize = 13.sp)
        Text("Version 1.0.0-debug (debug build, not a signed release)", color = c.textSecondary, fontSize = 12.sp)
    }

    if (confirmStats) ConfirmDialog(
        "Clear statistics?", "Session history will be deleted.", "Clear",
        { vm.clearStats(); confirmStats = false }, { confirmStats = false }
    )
    if (confirmAll) ConfirmDialog(
        "Delete all data?", "Schedules, allowed apps and statistics will be deleted. Active focus ends.", "Delete",
        { vm.deleteAllData(); confirmAll = false }, { confirmAll = false }
    )
}

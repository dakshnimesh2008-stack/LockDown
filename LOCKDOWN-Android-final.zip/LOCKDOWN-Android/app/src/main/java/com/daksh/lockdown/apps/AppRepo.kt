package com.daksh.lockdown.apps

import android.content.Context
import android.content.Intent
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppInfo(val packageName: String, val label: String)

object AppRepo {
    /** Launchable apps only (package visibility comes from the <queries> launcher intent in the manifest). */
    fun launchable(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0)
            .map { AppInfo(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.packageName != ctx.packageName }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    /** Null when the app is no longer installed / launchable. */
    fun label(ctx: Context, pkg: String): String? = try {
        if (ctx.packageManager.getLaunchIntentForPackage(pkg) == null) null
        else ctx.packageManager.getApplicationInfo(pkg, 0).loadLabel(ctx.packageManager).toString()
    } catch (e: Exception) {
        null
    }

    fun launch(ctx: Context, pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }
}

object IconCache {
    private val cache = LruCache<String, ImageBitmap>(160)

    fun cached(pkg: String): ImageBitmap? = cache.get(pkg)

    fun load(ctx: Context, pkg: String): ImageBitmap? {
        cache.get(pkg)?.let { return it }
        return try {
            val bmp = ctx.packageManager.getApplicationIcon(pkg).toBitmap(120, 120).asImageBitmap()
            cache.put(pkg, bmp)
            bmp
        } catch (e: Exception) {
            null
        }
    }
}

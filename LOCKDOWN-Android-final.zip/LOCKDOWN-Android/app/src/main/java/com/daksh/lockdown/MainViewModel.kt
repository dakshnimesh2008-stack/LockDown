package com.daksh.lockdown

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.daksh.lockdown.apps.AppInfo
import com.daksh.lockdown.apps.AppRepo
import com.daksh.lockdown.data.AllowedAppEntity
import com.daksh.lockdown.data.Graph
import com.daksh.lockdown.data.ScheduleEntity
import com.daksh.lockdown.data.SessionEntity
import com.daksh.lockdown.engine.FocusEngine
import com.daksh.lockdown.logic.FocusLogic
import com.daksh.lockdown.logic.FocusState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Application get() = getApplication()
    private val db = Graph.db
    private val scheduleDao = db.scheduleDao()
    private val sessionDao = db.sessionDao()
    private val appDao = db.allowedAppDao()

    val schedules: StateFlow<List<ScheduleEntity>> =
        scheduleDao.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val sessions: StateFlow<List<SessionEntity>> =
        sessionDao.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val allowed: StateFlow<List<AllowedAppEntity>> =
        appDao.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val installedApps = MutableStateFlow<List<AppInfo>>(emptyList())

    private val _now = MutableStateFlow(System.currentTimeMillis())
    val now: StateFlow<Long> = _now

    /** Derived from persisted session records; the clock only decides which of them are still running. */
    val focusState: StateFlow<FocusState> =
        combine(sessions, schedules, allowed, _now) { ss, sc, al, n ->
            FocusLogic.compute(ss, sc, al.map { it.packageName }, n)
        }.distinctUntilChanged().stateIn(viewModelScope, SharingStarted.Eagerly, FocusState())

    val homeEvent = MutableStateFlow(0)
    val banner = MutableStateFlow<String?>(null)

    init {
        refreshApps()
        viewModelScope.launch {
            var n = 0
            while (true) {
                val t = System.currentTimeMillis()
                _now.value = t
                val expired = sessions.value.any { it.outcome == "ACTIVE" && t >= it.plannedEndMs }
                if (expired || n % 15 == 0) FocusEngine.sync(ctx)
                n++
                delay(1000)
            }
        }
    }

    fun syncNow() {
        viewModelScope.launch { FocusEngine.sync(ctx) }
    }

    fun refreshApps() {
        viewModelScope.launch(Dispatchers.IO) { installedApps.value = AppRepo.launchable(ctx) }
    }

    fun onHomePressed() {
        homeEvent.value = homeEvent.value + 1
        if (focusState.value.isActive) {
            banner.value = "Focus mode is on. Only your allowed apps are available."
            viewModelScope.launch {
                delay(6000)
                banner.value = null
            }
        }
    }

    // ---- focus sessions ----
    fun startManual(minutes: Int) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val t = System.currentTimeMillis()
                sessionDao.insert(
                    SessionEntity(
                        scheduleId = null, name = "Focus Session",
                        startMs = t, plannedEndMs = t + minutes * 60_000L,
                        endedMs = null, outcome = "ACTIVE"
                    )
                )
            }
            FocusEngine.sync(ctx)
        }
    }

    fun endFocus() {
        viewModelScope.launch { FocusEngine.endAll(ctx) }
    }

    // ---- schedules ----
    fun saveSchedule(s: ScheduleEntity) {
        viewModelScope.launch {
            val old = schedules.value.firstOrNull { it.id == s.id }
            if (s.id == 0L) {
                withContext(Dispatchers.IO) { scheduleDao.insert(s) }
            } else {
                withContext(Dispatchers.IO) { scheduleDao.update(s) }
                if (old != null && (old.startMinute != s.startMinute || old.endMinute != s.endMinute ||
                        old.daysMask != s.daysMask || (old.enabled && !s.enabled))
                ) FocusEngine.interruptSchedule(ctx, s.id)
            }
            FocusEngine.sync(ctx)
        }
    }

    fun setScheduleEnabled(s: ScheduleEntity, enabled: Boolean) = saveSchedule(s.copy(enabled = enabled))

    fun duplicateSchedule(s: ScheduleEntity) {
        saveSchedule(s.copy(id = 0, name = s.name + " (copy)"))
    }

    fun deleteSchedule(s: ScheduleEntity) {
        viewModelScope.launch {
            FocusEngine.interruptSchedule(ctx, s.id)
            withContext(Dispatchers.IO) { scheduleDao.delete(s) }
            FocusEngine.sync(ctx)
        }
    }

    // ---- allowed apps (saved immediately and persisted) ----
    private fun writeApps(pkgs: List<String>) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                appDao.replaceAll(pkgs.mapIndexed { i, p -> AllowedAppEntity(p, i) })
            }
        }
    }

    fun toggleApp(pkg: String) {
        val cur = allowed.value.map { it.packageName }
        writeApps(if (pkg in cur) cur - pkg else cur + pkg)
    }

    fun moveApp(pkg: String, delta: Int) {
        val cur = allowed.value.map { it.packageName }.toMutableList()
        val i = cur.indexOf(pkg)
        val j = i + delta
        if (i < 0 || j < 0 || j >= cur.size) return
        cur[i] = cur[j].also { cur[j] = cur[i] }
        writeApps(cur)
    }

    // ---- data deletion ----
    fun clearStats() {
        viewModelScope.launch { withContext(Dispatchers.IO) { sessionDao.clearFinished() } }
    }

    fun deleteAllData() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { db.clearAllTables() }
            FocusEngine.sync(ctx)
        }
    }
}

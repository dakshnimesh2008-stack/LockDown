package com.daksh.lockdown

import android.app.Application
import com.daksh.lockdown.data.Graph

class LockdownApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Graph.init(this)
    }
}

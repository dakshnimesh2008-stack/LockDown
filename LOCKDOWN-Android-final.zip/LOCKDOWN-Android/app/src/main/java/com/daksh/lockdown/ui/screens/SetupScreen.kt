package com.daksh.lockdown.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.daksh.lockdown.engine.Perms
import com.daksh.lockdown.ui.components.*
import com.daksh.lockdown.ui.theme.LocalLockdownColors

private const val LAST_STEP = 5

@Composable
fun SetupScreen(onOpenApps: () -> Unit, onOpenAddSchedule: () -> Unit, onFinish: () -> Unit) {
    val c = LocalLockdownColors.current
    val ctx = LocalContext.current
    var step by rememberSaveable { mutableIntStateOf(0) }
    val tick = rememberResumeTick()
    var refresh by remember { mutableIntStateOf(0) }
    val notif = remember(tick, refresh) { Perms.notificationsGranted(ctx) }
    val exact = remember(tick, refresh) { Perms.canExactAlarms(ctx) }
    val home = remember(tick, refresh) { Perms.isDefaultHome(ctx) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { refresh++ }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("LOCKDOWN setup  ${step + 1}/${LAST_STEP + 1}", color = c.accentSoft, fontSize = 13.sp)
        when (step) {
            0 -> {
                Text("Focus Today. Better Tomorrow.", color = c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(
                    "LOCKDOWN lets you create alarm-style focus schedules. While focus is on, your home screen shows only " +
                        "the apps you chose, so you can study, work or sleep without distractions. " +
                        "Everything stays on your phone: no login, ads or tracking.",
                    color = c.textSecondary, fontSize = 15.sp
                )
                Text(LIMITATION_TEXT, color = c.textSecondary, fontSize = 13.sp)
            }
            1 -> {
                Text("Choose allowed apps", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Pick the apps that stay available during focus, for example Phone, Calculator or a notes app.", color = c.textSecondary, fontSize = 15.sp)
                PrimaryButton("Choose apps", Modifier.fillMaxWidth(), onOpenApps)
            }
            2 -> {
                Text("Create your first schedule", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Set a name, start and end time and the days it repeats. You can add as many as you like.", color = c.textSecondary, fontSize = 15.sp)
                PrimaryButton("Add a schedule", Modifier.fillMaxWidth(), onOpenAddSchedule)
            }
            3 -> {
                Text("Set LOCKDOWN as Home app", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(
                    "Open Home settings, choose LOCKDOWN as your Home app and confirm. " +
                        "To go back later, pick your old launcher in the same place. This step is optional.",
                    color = c.textSecondary, fontSize = 15.sp
                )
                PermissionRow("Default Home app", "Shown as On only when Android reports LOCKDOWN as the default.", home, "Open Home settings") {
                    openSafely(ctx, homeSettingsIntent())
                }
            }
            4 -> {
                Text("Permissions", color = c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Both are optional. LOCKDOWN still works in a limited mode if you skip them.", color = c.textSecondary, fontSize = 15.sp)
                PermissionRow("Notifications", "Tells you when a focus session starts or ends.", notif, "Allow") {
                    if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    else openSafely(ctx, notificationSettingsIntent(ctx))
                }
                PermissionRow("Exact alarms", "Starts and ends sessions on the exact minute. Without it sessions may start a little late.", exact, "Open alarm settings") {
                    openSafely(ctx, exactAlarmIntent(ctx))
                }
            }
            else -> {
                Text("You're ready", color = c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text("Emergency calls always remain available from the focus screen. You can rerun this guide any time from Settings.", color = c.textSecondary, fontSize = 15.sp)
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (step > 0) SecondaryButton("Back", Modifier.weight(1f)) { step-- }
            if (step < LAST_STEP) PrimaryButton(if (step in 1..4) "Next" else "Start", Modifier.weight(1f)) { step++ }
            else PrimaryButton("Finish", Modifier.weight(1f), onFinish)
        }
        if (step < LAST_STEP) {
            SecondaryButton("Skip setup", Modifier.fillMaxWidth(), onFinish)
        }
    }
}

package com.daksh.lockdown.engine

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.daksh.lockdown.data.Graph
import com.daksh.lockdown.data.SessionEntity
import com.daksh.lockdown.logic.ScheduleLogic
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZoneId

/**
 * Single source of truth for focus state.
 *  - closes sessions whose end time passed (also after reboot / power-off),
 *  - opens sessions for schedule windows that contain "now" (never twice for the same window),
 *  - registers ONE OS alarm for the next required event (no per-schedule alarms, so no duplicates).
 * Safe to call at any time: app start, alarm, boot, clock or time-zone change.
 */
object FocusEngine {
    private val mutex = Mutex()
    const val ACTION_TICK = "com.daksh.lockdown.TICK"

    suspend fun sync(ctx: Context) {
        val app = ctx.applicationContext
        withContext(Dispatchers.IO) {
            mutex.withLock {
                val sdao = Graph.db.scheduleDao()
                val ssdao = Graph.db.sessionDao()
                val now = System.currentTimeMillis()

                for (a in ssdao.getActiveList()) {
                    if (now >= a.plannedEndMs) {
                        ssdao.update(a.copy(endedMs = a.plannedEndMs, outcome = "COMPLETED"))
                        finished(app, a, completed = true)
                    }
                }

                val zdt = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault())
                for (s in sdao.getAll().filter { it.enabled }) {
                    val w = ScheduleLogic.activeWindow(s, zdt) ?: continue
                    if (ssdao.find(s.id, w.first) == null) {
                        ssdao.insert(
                            SessionEntity(
                                scheduleId = s.id, name = s.name,
                                startMs = w.first, plannedEndMs = w.second,
                                endedMs = null, outcome = "ACTIVE"
                            )
                        )
                        if (s.notify) Notifier.post(app, 1000 + s.id.toInt(), "Focus started", s.name)
                    }
                }

                scheduleAlarm(app, now)
            }
        }
    }

    /** Ends every active session early. Recorded honestly as INTERRUPTED. */
    suspend fun endAll(ctx: Context) {
        withContext(Dispatchers.IO) {
            mutex.withLock {
                val ssdao = Graph.db.sessionDao()
                val now = System.currentTimeMillis()
                for (a in ssdao.getActiveList()) {
                    ssdao.update(a.copy(endedMs = now, outcome = "INTERRUPTED"))
                    finished(ctx.applicationContext, a, completed = false)
                }
                scheduleAlarm(ctx.applicationContext, now)
            }
        }
    }

    /** Used when a schedule is edited, disabled or deleted while its session is running. */
    suspend fun interruptSchedule(ctx: Context, scheduleId: Long) {
        withContext(Dispatchers.IO) {
            mutex.withLock {
                val ssdao = Graph.db.sessionDao()
                val now = System.currentTimeMillis()
                for (a in ssdao.getActiveList().filter { it.scheduleId == scheduleId }) {
                    ssdao.update(a.copy(endedMs = now, outcome = "INTERRUPTED"))
                }
            }
        }
    }

    private suspend fun finished(app: Context, a: SessionEntity, completed: Boolean) {
        val sid = a.scheduleId ?: return
        val sdao = Graph.db.scheduleDao()
        val s = sdao.getById(sid) ?: return
        if (s.daysMask == 0) sdao.update(s.copy(enabled = false)) // one-time schedules run once
        if (completed && s.notify) Notifier.post(app, 2000 + s.id.toInt(), "Focus complete", s.name)
    }

    private suspend fun scheduleAlarm(app: Context, now: Long) {
        val active = Graph.db.sessionDao().getActiveList()
        val schedules = Graph.db.scheduleDao().getAll().filter { it.enabled }
        val zdt = Instant.ofEpochMilli(now).atZone(ZoneId.systemDefault())
        var next = Long.MAX_VALUE
        active.forEach { next = minOf(next, it.plannedEndMs) }
        schedules.forEach { s ->
            ScheduleLogic.nextStart(s, zdt)?.let { next = minOf(next, it.toInstant().toEpochMilli()) }
        }

        val am = app.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            app, 1,
            Intent(app, FocusReceiver::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        if (next == Long.MAX_VALUE) {
            am.cancel(pi)
            return
        }
        try {
            if (Perms.canExactAlarms(app)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
            } else {
                // Documented fallback: inexact alarm, may fire a little late.
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next, pi)
        }
    }
}

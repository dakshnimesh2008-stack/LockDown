package com.daksh.lockdown

import com.daksh.lockdown.data.ScheduleEntity
import com.daksh.lockdown.data.SessionEntity
import com.daksh.lockdown.logic.FocusLogic
import com.daksh.lockdown.logic.ScheduleLogic
import com.daksh.lockdown.logic.StatsCalc
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.ZoneId
import java.time.ZonedDateTime

class LogicTest {
    private val zone = ZoneId.of("UTC")
    private fun sched(start: Int, end: Int, mask: Int, id: Long = 1, pk: String? = null) =
        ScheduleEntity(id = id, name = "S$id", startMinute = start, endMinute = end, daysMask = mask, allowedPackages = pk)

    @Test fun daysLabel() {
        assertEquals("Every day", ScheduleLogic.daysLabel(127))
        assertEquals("One time", ScheduleLogic.daysLabel(0))
        assertEquals("Mon, Wed", ScheduleLogic.daysLabel(5))
    }

    @Test fun overnightDetected() {
        assertTrue(ScheduleLogic.crossesMidnight(sched(22 * 60 + 30, 6 * 60, 127)))
    }

    @Test fun nextStartSkipsDisabledWeekdays() {
        // 2026-10-19 is a Monday; schedule only on Wednesday (bit 2)
        val now = ZonedDateTime.of(2026, 10, 19, 10, 0, 0, 0, zone)
        val next = ScheduleLogic.nextStart(sched(9 * 60, 12 * 60, 4), now)!!
        assertEquals(21, next.dayOfMonth)
        assertEquals(9, next.hour)
    }

    @Test fun overnightWindowActiveAfterMidnight() {
        val s = sched(22 * 60, 6 * 60, 127)
        val at = ZonedDateTime.of(2026, 10, 20, 2, 0, 0, 0, zone)
        val w = ScheduleLogic.activeWindow(s, at)
        assertNotNull(w)
        assertEquals(ZonedDateTime.of(2026, 10, 19, 22, 0, 0, 0, zone).toInstant().toEpochMilli(), w!!.first)
        assertEquals(ZonedDateTime.of(2026, 10, 20, 6, 0, 0, 0, zone).toInstant().toEpochMilli(), w.second)
    }

    @Test fun noWindowOutsideTimeOrDay() {
        val s = sched(9 * 60, 12 * 60, 4) // Wednesday only
        assertNull(ScheduleLogic.activeWindow(s, ZonedDateTime.of(2026, 10, 19, 10, 0, 0, 0, zone))) // Monday
        assertNull(ScheduleLogic.activeWindow(s, ZonedDateTime.of(2026, 10, 21, 13, 0, 0, 0, zone))) // after end
        assertNotNull(ScheduleLogic.activeWindow(s, ZonedDateTime.of(2026, 10, 21, 10, 0, 0, 0, zone)))
    }

    @Test fun overlapDetection() {
        assertTrue(ScheduleLogic.overlaps(sched(9 * 60, 12 * 60, 127), sched(11 * 60, 13 * 60, 127, 2)))
        assertFalse(ScheduleLogic.overlaps(sched(9 * 60, 12 * 60, 127), sched(12 * 60, 13 * 60, 127, 2)))
        // overnight Mon 22:00 -> Tue 06:00 overlaps a Tuesday 05:00-07:00 schedule, not a Wednesday one
        assertTrue(ScheduleLogic.overlaps(sched(22 * 60, 6 * 60, 1), sched(5 * 60, 7 * 60, 2, 2)))
        assertFalse(ScheduleLogic.overlaps(sched(22 * 60, 6 * 60, 1), sched(5 * 60, 7 * 60, 4, 2)))
    }

    private fun active(sid: Long?) = SessionEntity(
        scheduleId = sid, name = "x", startMs = 0, plannedEndMs = 10_000, endedMs = null, outcome = "ACTIVE"
    )

    @Test fun whitelistIntersection() {
        val schedules = listOf(sched(0, 60, 127, 1, "a,b"), sched(0, 60, 127, 2, "b,c"), sched(0, 60, 127, 3, null))
        val allowed = listOf("a", "b", "c")
        val s = FocusLogic.compute(listOf(active(1), active(2), active(3)), schedules, allowed, now = 5_000)
        assertEquals(listOf("b"), s.effectiveApps)
        assertFalse(s.conflict)
        val s2 = FocusLogic.compute(listOf(active(1), active(null)), listOf(sched(0, 60, 127, 1, "a")), allowed, 5_000)
        assertEquals(listOf("a"), s2.effectiveApps)
    }

    @Test fun emptyIntersectionIsConflict() {
        val schedules = listOf(sched(0, 60, 127, 1, "a"), sched(0, 60, 127, 2, "b"))
        val s = FocusLogic.compute(listOf(active(1), active(2)), schedules, listOf("a", "b"), 5_000)
        assertTrue(s.conflict)
        assertTrue(s.effectiveApps.isEmpty())
    }

    @Test fun expiredSessionsAreNotActive() {
        assertFalse(FocusLogic.compute(listOf(active(null)), emptyList(), listOf("a"), now = 20_000).isActive)
    }

    @Test fun streakAndTodayStats() {
        val now = ZonedDateTime.of(2026, 10, 19, 12, 0, 0, 0, ZoneId.systemDefault()).toInstant().toEpochMilli()
        fun done(daysAgo: Long) = SessionEntity(
            scheduleId = null, name = "x",
            startMs = now - daysAgo * 86_400_000L - 1_800_000L,
            plannedEndMs = now - daysAgo * 86_400_000L,
            endedMs = now - daysAgo * 86_400_000L, outcome = "COMPLETED"
        )
        val list = listOf(done(0), done(1), done(2), done(4))
        val stats = StatsCalc.compute(list, now)
        assertEquals(1, stats.completedToday)
        assertEquals(3, stats.streak)
        assertEquals(1_800_000L, stats.focusMsToday)
        val full = StatsCalc.full(list, now)
        assertEquals(3, full.streak)
        assertEquals(3, full.bestStreak)
        assertEquals(4, full.completed)
        assertEquals(7, full.last7.size)
    }

    @Test fun clockFormat() {
        assertEquals("02:14:36", StatsCalc.formatClock((2 * 3600 + 14 * 60 + 36) * 1000L))
    }
}

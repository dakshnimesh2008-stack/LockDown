package com.daksh.lockdown;
import android.content.*;
public class UnlockReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        // The timer end only dismisses LOCKDOWN's focus screen; it does not forcibly
        // exit Android kiosk mode. Device-owner kiosk provisioning is intentionally not
        // enabled automatically in this starter project.
        context.getSharedPreferences("lockdown",Context.MODE_PRIVATE).edit().putLong("end",0).apply();
        Intent i=new Intent(context,LockActivity.class);
        i.setAction("com.daksh.lockdown.FINISH");
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { context.startActivity(i); } catch(Exception ignored) {}
    }
}

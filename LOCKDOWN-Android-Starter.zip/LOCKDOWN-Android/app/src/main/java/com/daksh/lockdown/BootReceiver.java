package com.daksh.lockdown;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if(Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            long start=context.getSharedPreferences("lockdown",Context.MODE_PRIVATE).getLong("start",0);
            if(start>System.currentTimeMillis()) {
                Intent i=new Intent(context,ScheduleReceiver.class);
                android.app.PendingIntent pi=android.app.PendingIntent.getBroadcast(context,1,i,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT|android.app.PendingIntent.FLAG_IMMUTABLE);
                android.app.AlarmManager am=(android.app.AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
                try { am.setExactAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP,start,pi); }
                catch(Exception e) { am.set(android.app.AlarmManager.RTC_WAKEUP,start,pi); }
            }
        }
    }
}

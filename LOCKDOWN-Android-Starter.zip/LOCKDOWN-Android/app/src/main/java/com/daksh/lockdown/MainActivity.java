package com.daksh.lockdown;

import android.app.*;
import android.app.admin.DevicePolicyManager;
import android.content.*;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.*;
import java.util.Calendar;

public class MainActivity extends Activity {
    private static final int ADMIN_REQ = 41;
    private TextView status;
    private int hour = 21, minute = 0, duration = 60;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,5,8));
        getWindow().setNavigationBarColor(Color.rgb(5,5,8));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(28, 42, 28, 28);
        page.setBackgroundColor(Color.rgb(5,5,8));
        ScrollView scroll = new ScrollView(this);
        scroll.addView(page);
        setContentView(scroll);

        TextView brand = text("LOCKDOWN", 30, Color.WHITE);
        brand.setLetterSpacing(.12f);
        page.addView(brand);
        TextView tagline = text("FOCUS MODE  /  TAKE BACK YOUR TIME", 12, Color.rgb(173,143,255));
        tagline.setPadding(0, 6, 0, 28); page.addView(tagline);

        TextView cardTitle = text("Scheduled phone restriction", 20, Color.WHITE);
        page.addView(cardTitle);
        TextView explainer = text("Schedule a focus window. Full-device kiosk restriction requires this app to be provisioned as Device Owner. Normal installs cannot silently lock the entire phone.", 14, Color.LTGRAY);
        explainer.setPadding(0, 12, 0, 20); page.addView(explainer);

        Button time = button("Choose start time · 9:00 PM");
        time.setOnClickListener(v -> {
            new TimePickerDialog(this, (view, h, m) -> {
                hour=h; minute=m;
                time.setText(String.format("Choose start time · %02d:%02d",h,m));
            }, hour, minute, false).show();
        });
        page.addView(time, params());
        Spinner length = new Spinner(this);
        String[] choices = {"30 minutes", "1 hour", "2 hours", "3 hours", "4 hours"};
        length.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, choices));
        length.setSelection(1);
        length.setBackgroundColor(Color.rgb(24,24,32));
        length.setPadding(12, 12, 12, 12);
        length.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
            public void onItemSelected(android.widget.AdapterView<?> p, android.view.View v, int pos, long id) {
                int[] mins={30,60,120,180,240}; duration=mins[pos];
            }
        });
        LinearLayout.LayoutParams sp = params(); sp.topMargin=12; page.addView(length, sp);

        Button schedule = button("SAVE FOCUS SCHEDULE");
        schedule.setOnClickListener(v -> saveSchedule());
        LinearLayout.LayoutParams bp=params(); bp.topMargin=18; page.addView(schedule,bp);

        Button admin = button("SET UP DEVICE OWNER / ADMIN");
        admin.setOnClickListener(v -> {
            Intent i = new Intent(this, AdminReceiver.class);
            // Device admin activation is not Device Owner provisioning; label this honestly.
            Intent activate = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            activate.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                    new ComponentName(this, AdminReceiver.class));
            activate.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Allows LOCKDOWN to request a normal device lock. This alone does not enable whole-device kiosk mode.");
            startActivityForResult(activate, ADMIN_REQ);
        });
        LinearLayout.LayoutParams ap=params(); ap.topMargin=10; page.addView(admin,ap);

        Button test = button("TEST LOCK SCREEN");
        test.setOnClickListener(v -> startActivity(new Intent(this, LockActivity.class)));
        LinearLayout.LayoutParams tp=params(); tp.topMargin=10; page.addView(test,tp);

        status = text("STATUS  ·  No schedule saved", 13, Color.rgb(173,143,255));
        status.setPadding(0,24,0,8); page.addView(status);
        TextView safety = text("Safety: emergency calling and system functions must remain available. Never provision as Device Owner on your primary phone unless you understand Android kiosk-mode recovery and removal requirements.", 12, Color.GRAY);
        safety.setPadding(0,12,0,0); page.addView(safety);
    }
    private TextView text(String s,int size,int color) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private Button button(String s) {
        Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(85,55,190)));
        return b;
    }
    private LinearLayout.LayoutParams params() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }
    private void saveSchedule() {
        Calendar c=Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY,hour); c.set(Calendar.MINUTE,minute); c.set(Calendar.SECOND,0); c.set(Calendar.MILLISECOND,0);
        if(c.getTimeInMillis()<=System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR,1);
        long start=c.getTimeInMillis(), end=start+duration*60_000L;
        getSharedPreferences("lockdown",MODE_PRIVATE).edit().putLong("start",start).putLong("end",end).apply();
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        Intent intent=new Intent(this,ScheduleReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(this,1,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        try {
            if(android.os.Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) {
                startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM));
                status.setText("Allow exact alarms, then save the schedule again.");
                return;
            }
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,start,pi);
            status.setText("SCHEDULE SAVED  ·  "+String.format("%02d:%02d",hour,minute)+" · "+duration+" min");
            Toast.makeText(this,"Schedule saved on this device.",Toast.LENGTH_LONG).show();
        } catch(Exception e) {
            am.set(AlarmManager.RTC_WAKEUP,start,pi);
            status.setText("Schedule saved with Android's best-effort alarm.");
        }
    }
}

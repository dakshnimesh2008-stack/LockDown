package com.daksh.lockdown;
import android.app.*;
import android.app.admin.DevicePolicyManager;
import android.content.*;
import android.os.Build;

public class ScheduleReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        long end=context.getSharedPreferences("lockdown",Context.MODE_PRIVATE).getLong("end",0);
        if(end<=System.currentTimeMillis()) return;
        Intent lock=new Intent(context,LockActivity.class);
        lock.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        try { context.startActivity(lock); } catch(Exception ignored) { }
        AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        Intent unlockIntent=new Intent(context,UnlockReceiver.class);
        unlockIntent.putExtra("end",end);
        PendingIntent unlock=PendingIntent.getBroadcast(context,2,unlockIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        try { am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,end,unlock); }
        catch(Exception e) { am.set(AlarmManager.RTC_WAKEUP,end,unlock); }
    }
}

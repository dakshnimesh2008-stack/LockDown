package com.daksh.lockdown;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.*;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import java.util.concurrent.TimeUnit;

public class LockActivity extends Activity {
    private TextView timer;
    private android.os.Handler handler=new android.os.Handler();
    private Runnable ticker;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if ("com.daksh.lockdown.FINISH".equals(getIntent().getAction())) { finish(); return; }
        getWindow().setStatusBarColor(Color.rgb(5,5,8));
        getWindow().setNavigationBarColor(Color.rgb(5,5,8));
        LinearLayout root=new LinearLayout(this); root.setOrientation(1);
        root.setGravity(Gravity.CENTER); root.setPadding(30,30,30,30); root.setBackgroundColor(Color.rgb(5,5,8));
        TextView icon=new TextView(this); icon.setText("◈"); icon.setTextSize(64); icon.setTextColor(Color.rgb(173,143,255)); icon.setGravity(Gravity.CENTER);
        root.addView(icon);
        TextView title=new TextView(this); title.setText("LOCKDOWN"); title.setTextSize(30); title.setTextColor(Color.WHITE); title.setGravity(Gravity.CENTER); title.setLetterSpacing(.12f);
        root.addView(title);
        TextView sub=new TextView(this); sub.setText("FOCUS SESSION ACTIVE"); sub.setTextSize(12); sub.setTextColor(Color.rgb(173,143,255)); sub.setGravity(Gravity.CENTER); sub.setPadding(0,12,0,24);
        root.addView(sub);
        timer=new TextView(this); timer.setTextSize(42); timer.setTextColor(Color.WHITE); timer.setGravity(Gravity.CENTER); root.addView(timer);
        TextView info=new TextView(this); info.setText("Your scheduled focus time is in progress. Emergency calls remain available through Android's system UI."); info.setTextSize(14); info.setTextColor(Color.LTGRAY); info.setGravity(Gravity.CENTER); info.setPadding(0,24,0,24); root.addView(info);
        Button exit=new Button(this); exit.setText("EXIT FOCUS SCREEN"); exit.setOnClickListener(v -> finish()); root.addView(exit);
        setContentView(root);
        ticker=()->{
            long end=getSharedPreferences("lockdown",MODE_PRIVATE).getLong("end",0);
            long left=end-System.currentTimeMillis();
            if(left<=0){ finish(); return; }
            timer.setText(String.format("%02d:%02d:%02d",TimeUnit.MILLISECONDS.toHours(left),TimeUnit.MILLISECONDS.toMinutes(left)%60,TimeUnit.MILLISECONDS.toSeconds(left)%60));
            handler.postDelayed(ticker,1000);
        };
        handler.post(ticker);
    }
    @Override protected void onDestroy(){ super.onDestroy(); if(ticker!=null) handler.removeCallbacks(ticker); }
}

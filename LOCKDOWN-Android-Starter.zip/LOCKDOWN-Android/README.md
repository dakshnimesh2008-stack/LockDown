# LOCKDOWN — Android starter

Offline-first Android app prototype for scheduled focus sessions. No login, no ads, no network permission.

## Important limitation
A normal Android app cannot silently restrict the entire device. Full-device kiosk/lock-task mode requires Device Owner provisioning and a carefully designed allowlist. This starter deliberately does **not** enable kiosk mode automatically or trap the user. The current build schedules a focus screen and countdown; it is not yet a true whole-phone lock. Emergency/system functionality must remain accessible.

## Build APK from your Android phone
1. Create a new GitHub repository named `LOCKDOWN-Android`.
2. Upload the **contents** of this ZIP to the repository root (not the ZIP itself).
3. Open **Actions** → **Build LOCKDOWN APK** → **Run workflow**.
4. When it finishes, open the workflow run → **Artifacts** → download `LOCKDOWN-debug-apk`.
5. Extract the artifact ZIP and install `app-debug.apk` on your Android device. You may need to allow installs from your browser/files app.

## Build locally
Requires JDK 17, Android SDK platform 35 and Gradle 8.9+.
`gradle assembleDebug`

## Next milestone
Add an explicit, reversible Device Owner/kiosk setup guide and validate supported behavior on a test device before implementing whole-device restrictions. Do not test kiosk provisioning on your primary phone without a recovery plan.
